// This file contains functions for working with a list of words read
// from a text file. You do not need to modify anything in here.

#pragma once

void readWords();
std::string chooseRandomWord();
